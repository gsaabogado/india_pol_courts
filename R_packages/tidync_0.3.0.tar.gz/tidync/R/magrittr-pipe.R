#' @importFrom magrittr %>%
#' @export
#' @examples 
#' system.file("extdata/argo/MD5903593_001.nc", package = "tidync") %>% 
#'      tidync()
magrittr::`%>%`

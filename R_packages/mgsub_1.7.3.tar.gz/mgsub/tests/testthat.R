library(testthat)
library(mgsub)

test_check("mgsub")
